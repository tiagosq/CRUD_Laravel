<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/app.css')); ?>" />
        <title>CRUD</title>
    </head>
    <body class="antialiased">
        <div class="relative flex items-top justify-center min-h-screen bg-gray-100 dark:bg-gray-900 sm:items-center sm:pt-0">
        <h1>Table<span class="yellow"> Products</span></h1>
        <h2>by Felipe Kowalczuk</h2>
        <div class="action">
            <a href="product">New Product</a>
        </div>
        <table class="container">
            <thead>
                <tr>
                    <th><h1>id</h1></th>
                    <th><h1>name</h1></th>
                    <th><h1>description</h1></th>
                    <th><h1>type</h1></th>
                    <th><h1>price</h1></th>
                    <th><h1>created_at</h1></th>
                    <th><h1>updated_at</h1></th>
                    <th><h1>actions</h1></th>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($prod->id); ?></td>
                    <td><?php echo e($prod->name); ?></td>
                    <td><?php echo e($prod->description); ?></td>
                    <td><?php echo e($prod->type); ?></td>
                    <td><?php echo e($prod->price); ?></td>
                    <td><?php echo e($prod->created_at->format("d/m/Y")); ?></td>
                    <td><?php echo e($prod->updated_at->format("d/m/Y")); ?></td>
                    <td>
                        <a href="product/<?php echo e($prod->id); ?>">Editar</a>
                        <a href="product/remove/<?php echo e($prod->id); ?>">Delete</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8">No Results</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
        </div>
    </body>
</html>
<?php /**PATH C:\xampp_server\htdocs\aula_php\aula-app\resources\views/list.blade.php ENDPATH**/ ?>